export type OptionProps = {
    label: string;
    optionAction: () => void;
    primary?: Boolean;
    toggle?: Boolean;
};

